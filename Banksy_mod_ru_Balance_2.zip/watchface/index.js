﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_stand_icon_img = ''
        let normal_vo2max_icon_img = ''
        let normal_pressure_text_text_img = ''
        let normal_pressure_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 285,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 287,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 275,
              image_array: ["set_35_45x45_h247s6b114_img_level_1.png","set_35_45x45_h247s6b114_img_level_2.png","set_35_45x45_h247s6b114_img_level_3.png","set_35_45x45_h247s6b114_img_level_4.png","set_35_45x45_h247s6b114_img_level_5.png","set_35_45x45_h247s6b114_img_level_6.png","set_35_45x45_h247s6b114_img_level_7.png","set_35_45x45_h247s6b114_img_level_8.png","set_35_45x45_h247s6b114_img_level_9.png","set_35_45x45_h247s6b114_img_level_10.png","set_35_45x45_h247s6b114_img_level_11.png"],
              image_length: 11,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 285,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'prbl30.png',
              unit_tc: 'prbl30.png',
              unit_en: 'prbl30.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 288,
              src: 'vlaz26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 183,
              src: 'chars_C814195D_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 78,
              src: 'element_custom_icon_1781543359454_213x25_h0s0b24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 235,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BARO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_pressure_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 237,
              src: 'barom26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 295,
              y: 158,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img.setAlpha(254);

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 146,
              y: 348,
              src: 'al26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 183,
              src: 'chars_C814195D_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 164,
              src: 'element_custom_icon_1781543359454_213x25_h0s0b24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 235,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 238,
              src: '0300.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 303,
              y: 225,
              image_array: ["set_35_45x45_h247s6b114_img_level_1.png","set_35_45x45_h247s6b114_img_level_2.png","set_35_45x45_h247s6b114_img_level_3.png","set_35_45x45_h247s6b114_img_level_4.png","set_35_45x45_h247s6b114_img_level_5.png","set_35_45x45_h247s6b114_img_level_6.png","set_35_45x45_h247s6b114_img_level_7.png","set_35_45x45_h247s6b114_img_level_8.png","set_35_45x45_h247s6b114_img_level_9.png","set_35_45x45_h247s6b114_img_level_10.png","set_35_45x45_h247s6b114_img_level_11.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 100,
              hour_array: ["chars_A51B8C1F_000.png","chars_A51B8C1F_001.png","chars_A51B8C1F_002.png","chars_A51B8C1F_003.png","chars_A51B8C1F_004.png","chars_A51B8C1F_005.png","chars_A51B8C1F_006.png","chars_A51B8C1F_007.png","chars_A51B8C1F_008.png","chars_A51B8C1F_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 176,
              minute_startY: 100,
              minute_array: ["chars_A51B8C1F_000.png","chars_A51B8C1F_001.png","chars_A51B8C1F_002.png","chars_A51B8C1F_003.png","chars_A51B8C1F_004.png","chars_A51B8C1F_005.png","chars_A51B8C1F_006.png","chars_A51B8C1F_007.png","chars_A51B8C1F_008.png","chars_A51B8C1F_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 252,
              second_startY: 120,
              second_array: ["chars_8734FFEB_000.png","chars_8734FFEB_001.png","chars_8734FFEB_002.png","chars_8734FFEB_003.png","chars_8734FFEB_004.png","chars_8734FFEB_005.png","chars_8734FFEB_006.png","chars_8734FFEB_007.png","chars_8734FFEB_008.png","chars_8734FFEB_009.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 80,
              src: 'chars_7A396818_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 59,
              week_en: ["0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              week_tc: ["0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              week_sc: ["0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 40,
              day_sc_array: ["0922.png","0923.png","0924.png","0925.png","0926.png","0927.png","0928.png","0929.png","0930.png","0931.png"],
              day_tc_array: ["0922.png","0923.png","0924.png","0925.png","0926.png","0927.png","0928.png","0929.png","0930.png","0931.png"],
              day_en_array: ["0922.png","0923.png","0924.png","0925.png","0926.png","0927.png","0928.png","0929.png","0930.png","0931.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 59,
              month_sc_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_tc_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_en_array: ["mon01.png","mon02.png","mon03.png","mon04.png","mon05.png","mon06.png","mon07.png","mon08.png","mon09.png","mon10.png","mon11.png","mon12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 335,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 325,
              image_array: ["set_35_45x45_h247s6b114_img_level_6.png","set_35_45x45_h247s6b114_img_level_7.png","set_35_45x45_h247s6b114_img_level_8.png","set_35_45x45_h247s6b114_img_level_9.png","set_35_45x45_h247s6b114_img_level_10.png","set_35_45x45_h247s6b114_img_level_11.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 337,
              src: 'custom_icon_1781422023219_30x30.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 375,
              image_array: ["set_35_45x45_h247s6b114_img_level_1.png","set_35_45x45_h247s6b114_img_level_2.png","set_35_45x45_h247s6b114_img_level_3.png","set_35_45x45_h247s6b114_img_level_4.png","set_35_45x45_h247s6b114_img_level_5.png","set_35_45x45_h247s6b114_img_level_6.png","set_35_45x45_h247s6b114_img_level_7.png","set_35_45x45_h247s6b114_img_level_8.png","set_35_45x45_h247s6b114_img_level_9.png","set_35_45x45_h247s6b114_img_level_10.png","set_35_45x45_h247s6b114_img_level_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 385,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'prbl30.png',
              unit_tc: 'prbl30.png',
              unit_en: 'prbl30.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 389,
              src: 'custom_icon_1781422075233_29x27.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 183,
              image_array: ["set_4_35x35_h0s0b200_meteo_1.png","set_4_35x35_h0s0b200_meteo_2.png","set_4_35x35_h0s0b200_meteo_3.png","set_4_35x35_h0s0b200_meteo_4.png","set_4_35x35_h0s0b200_meteo_5.png","set_4_35x35_h0s0b200_meteo_6.png","set_4_35x35_h0s0b200_meteo_7.png","set_4_35x35_h0s0b200_meteo_8.png","set_4_35x35_h0s0b200_meteo_9.png","set_4_35x35_h0s0b200_meteo_10.png","set_4_35x35_h0s0b200_meteo_11.png","set_4_35x35_h0s0b200_meteo_12.png","set_4_35x35_h0s0b200_meteo_13.png","set_4_35x35_h0s0b200_meteo_14.png","set_4_35x35_h0s0b200_meteo_15.png","set_4_35x35_h0s0b200_meteo_16.png","set_4_35x35_h0s0b200_meteo_17.png","set_4_35x35_h0s0b200_meteo_18.png","set_4_35x35_h0s0b200_meteo_19.png","set_4_35x35_h0s0b200_meteo_20.png","set_4_35x35_h0s0b200_meteo_21.png","set_4_35x35_h0s0b200_meteo_22.png","set_4_35x35_h0s0b200_meteo_23.png","set_4_35x35_h0s0b200_meteo_24.png","set_4_35x35_h0s0b200_meteo_25.png","set_4_35x35_h0s0b200_meteo_26.png","set_4_35x35_h0s0b200_meteo_27.png","set_4_35x35_h0s0b200_meteo_28.png","set_4_35x35_h0s0b200_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 185,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'chars_951408F2_011.png',
              unit_tc: 'chars_951408F2_011.png',
              unit_en: 'chars_951408F2_011.png',
              negative_image: 'chars_951408F2_010.png',
              invalid_image: 'chars_951408F2_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 185,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'chars_951408F2_011.png',
              unit_tc: 'chars_951408F2_011.png',
              unit_en: 'chars_951408F2_011.png',
              negative_image: 'chars_951408F2_010.png',
              invalid_image: 'chars_951408F2_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 212,
              src: 'chars_9CA7DD04_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 185,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'chars_951408F2_011.png',
              unit_tc: 'chars_951408F2_011.png',
              unit_en: 'chars_951408F2_011.png',
              negative_image: 'chars_951408F2_010.png',
              invalid_image: 'chars_951408F2_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 212,
              src: 'chars_478D226F_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secr20.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
              second_posY: 242,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg013.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 295,
              y: 158,
              src: 'btoffc.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img.setAlpha(254);

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 146,
              y: 348,
              src: 'al26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 100,
              hour_array: ["chars_7B85735D_000.png","chars_7B85735D_001.png","chars_7B85735D_002.png","chars_7B85735D_003.png","chars_7B85735D_004.png","chars_7B85735D_005.png","chars_7B85735D_006.png","chars_7B85735D_007.png","chars_7B85735D_008.png","chars_7B85735D_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 176,
              minute_startY: 100,
              minute_array: ["chars_7B85735D_000.png","chars_7B85735D_001.png","chars_7B85735D_002.png","chars_7B85735D_003.png","chars_7B85735D_004.png","chars_7B85735D_005.png","chars_7B85735D_006.png","chars_7B85735D_007.png","chars_7B85735D_008.png","chars_7B85735D_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 80,
              src: 'chars_F0867C2D_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 190,
              y: 188,
              week_en: ["dw01.png","dw02.png","dw03.png","dw04.png","dw05.png","dw06.png","dw07.png"],
              week_tc: ["dw01.png","dw02.png","dw03.png","dw04.png","dw05.png","dw06.png","dw07.png"],
              week_sc: ["dw01.png","dw02.png","dw03.png","dw04.png","dw05.png","dw06.png","dw07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 185,
              day_sc_array: ["0600.png","0601.png","0602.png","0603.png","0604.png","0605.png","0606.png","0607.png","0608.png","0609.png"],
              day_tc_array: ["0600.png","0601.png","0602.png","0603.png","0604.png","0605.png","0606.png","0607.png","0608.png","0609.png"],
              day_en_array: ["0600.png","0601.png","0602.png","0603.png","0604.png","0605.png","0606.png","0607.png","0608.png","0609.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 188,
              month_sc_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_tc_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_en_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 375,
              image_array: ["set_35_45x45_h247s6b114_img_level_1.png","set_35_45x45_h247s6b114_img_level_2.png","set_35_45x45_h247s6b114_img_level_3.png","set_35_45x45_h247s6b114_img_level_4.png","set_35_45x45_h247s6b114_img_level_5.png","set_35_45x45_h247s6b114_img_level_6.png","set_35_45x45_h247s6b114_img_level_7.png","set_35_45x45_h247s6b114_img_level_8.png","set_35_45x45_h247s6b114_img_level_9.png","set_35_45x45_h247s6b114_img_level_10.png","set_35_45x45_h247s6b114_img_level_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 385,
              font_array: ["chars_951408F2_000.png","chars_951408F2_001.png","chars_951408F2_002.png","chars_951408F2_003.png","chars_951408F2_004.png","chars_951408F2_005.png","chars_951408F2_006.png","chars_951408F2_007.png","chars_951408F2_008.png","chars_951408F2_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'prbl30.png',
              unit_tc: 'prbl30.png',
              unit_en: 'prbl30.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 389,
              src: 'custom_icon_1781422075233_29x27.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'secr20.png',
              // center_x: 240,
              // center_y: 240,
              // x: 10,
              // y: 242,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 10,
              pos_y: 240 - 242,
              center_x: 240,
              center_y: 240,
              src: 'secr20.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 210,
              w: 150,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 273,
              w: 150,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 335,
              w: 140,
              h: 60,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 60,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 180,
              w: 239,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 235,
              w: 100,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 95,
              w: 80,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 95,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 310,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 15,
              w: 100,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 400,
              w: 120,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Number
              let pressureValue = baroSensor.pressure;
              let normal_pressure_text = '-';
              if (pressureValue) normal_pressure_text = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_text_img.setProperty(hmUI.prop.TEXT, normal_pressure_text);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}